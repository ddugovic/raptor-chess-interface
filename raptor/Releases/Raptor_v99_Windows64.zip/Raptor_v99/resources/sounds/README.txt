You are free to replace sounds in these directories. As long as they are 
named the same you will encounter no issues as long as they are wav files.

Countdown sounds were taken from the THIEF project:
http://www.thief-interface.com/

Capture and ObsMove sounds taken from the OPEN ARENA project:
http://www.openarena.ws/
