This folder contains the users custoimzed regularExpression scripts.
http://code.google.com/p/raptor-chess-interface/wiki/Scripting for more details.