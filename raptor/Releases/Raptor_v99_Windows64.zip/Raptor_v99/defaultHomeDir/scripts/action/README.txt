This directory contains the users customized action scripts.
http://code.google.com/p/raptor-chess-interface/wiki/Scripting for more details.