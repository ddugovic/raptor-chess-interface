This directory contains a users customized scripts in Raptor.
http://code.google.com/p/raptor-chess-interface/wiki/Scripting for more details.