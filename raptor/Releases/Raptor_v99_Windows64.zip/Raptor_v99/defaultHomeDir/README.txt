This is the directory Raptor, a chess interface,
uses to store its user specific settings.