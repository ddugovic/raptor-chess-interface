   This directory is used by Raptor to store chat events from a Connector.
The files in this directory are deleted upon program exit and are used
to query previous ChatEvents that occurred in a connector. Channel tabs 
utilizes these files to enable adding tells to a newly created tab from all
events currently in the console..
