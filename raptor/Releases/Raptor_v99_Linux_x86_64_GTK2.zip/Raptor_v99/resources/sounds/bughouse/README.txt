The name of the sounds in this directory correspond to the text that has to be in the 
ptell to play them. A case insensitive check is involved. You can also add new sounds,
just name them to match what thief sends and after a restart they should work.


All of these sounds were obtained from the THIEF project: http://www.thief-interface.com/
