This folder contains files specific to BICS.
Currently this is being used to store extended lists.