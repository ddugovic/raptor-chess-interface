This folder contains the users customized parameter scripts.
http://code.google.com/p/raptor-chess-interface/wiki/Scripting for more details.